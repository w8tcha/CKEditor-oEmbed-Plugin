// French Translation by https://github.com/wissim

CKEDITOR.plugins.setLang('oembed', 'fr', {
	title : "Intégrer des contenus multimédia externes. (Photo, Video, Audio, ...)",
	button : "Insérer des contenus multimédia provenant de nombreux sites.",
	pasteUrl : "Coller l'URL de partage que vous voulez publier. De nombreux services sont pris en charge tels que : (YouTube, Flickr, Qik, Vimeo, Hulu, Viddler, MyOpera, etc.). Vous pouvez aussi utiliser les URLs courtes.",
	width : "Max. Largeur:",
	height : "Max. Hauteur:",
	invalidUrl : "Merci de fournir une URL valide !",
	noEmbedCode : "Aucun code d'intégration trouvé ou le site n'est pas supporté !",
	url : "URL:",
	widthTitle : "Maximum Width for the embeded Content",
	heightTitle : "Maximum Height for the embeded Content"
});
