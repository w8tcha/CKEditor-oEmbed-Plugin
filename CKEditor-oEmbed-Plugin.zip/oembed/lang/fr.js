// French Translation by https://github.com/wissim

CKEDITOR.plugins.setLang('oembed', 'fr', {
	title : "Intgrer des contenus multimédia externe. (Photo, Video, Audio, ...)",
	button : "Insérer des contenus multimédia à partir de divers sites de contenu.",
	pasteUrl : "Coller l'URL de partage que vous voulez publier. De nombreux services sont pris en charge (YouTube, Flickr, Qik, Vimeo, Hulu, Viddler, MyOpera, etc.). Vous pouvez aussi utiliser les URLs courtes.",
	width : "Max. Largeur:",
	height : "Max. Hauteur:",
	invalidUrl : "Merci de fournir une adresse valide !",
	noEmbedCode : "Aucun code d'intégration trouvé ou le site n'est pas supporté !"
});