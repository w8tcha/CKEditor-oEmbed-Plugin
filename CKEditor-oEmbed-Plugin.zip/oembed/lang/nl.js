CKEDITOR.plugins.setLang('oembed', 'nl', {
	title : "Integratie van media-inhoud (foto's, video, content)",
    button : "Media-inhoud van externe websites",
    pasteUrl : "Geef een URL van een pagina in dat ondersteund wordt (Bijv.: YouTube, Flickr, Qik, Vimeo, Hulu, Viddler, MyOpera, etc.) ...",
	width : "Maximale breedte:",
	height : "Maximale hoogte:",
	invalidUrl : "Please provide an valid URL!",
	noEmbedCode : "No embed code found, or site is not supported!",
	url : "URL:",
	widthTitle : "Maximum Width for the embeded Content",
	heightTitle : "Maximum Height for the embeded Content"
});